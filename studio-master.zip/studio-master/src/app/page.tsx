import { ImageGenerator } from "@/components/visionary-ai/ImageGenerator";
import { Toaster } from "@/components/ui/toaster";

export default function HomePage() {
  return (
    <>
      <ImageGenerator />
      <Toaster />
    </>
  );
}
