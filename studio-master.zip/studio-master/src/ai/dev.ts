import { config } from 'dotenv';
config();

import '@/ai/flows/generate-image-from-prompt.ts';
import '@/ai/flows/create-image-variations.ts';